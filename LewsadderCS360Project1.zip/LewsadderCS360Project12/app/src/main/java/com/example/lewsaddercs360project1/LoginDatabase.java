package com.example.lewsaddercs360project1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LoginDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_LOGIN = "login.db";
    private static final int VERSION = 1;
    private static final String TAG = "MyActivity";
    private static LoginDatabase LoginDB;

    private static final class LoginTable {
        private static final String TABLE = "LoginDatabase";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "USERNAME";
        private static final String COL_PASSWORD = "PASSWORD";
    }

    public LoginDatabase(Context context) {
        super(context, DATABASE_LOGIN, null, VERSION);
    }
    public static LoginDatabase getInstance(Context context) {
        if (LoginDB == null) {
            LoginDB = new LoginDatabase(context);
        }
        return LoginDB;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text)");

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_ID,"integer primary key autoincrement");
        values.put(LoginTable.COL_USERNAME,"admin");
        values.put(LoginTable.COL_PASSWORD,"password");
        db.insert(LoginTable.TABLE,null,values);
        Log.d(TAG,"Database created!!!");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }
    public long addUser(String storedUsername, String storedPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, storedPassword + storedPassword);
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_ID, " integer primary key, ");
        values.put(LoginTable.COL_USERNAME, storedUsername);
        values.put(LoginTable.COL_PASSWORD, storedPassword);
        long userId = db.insert(LoginTable.TABLE, null, values);
        Log.d(TAG, "Users added to database");
        return userId;
    }


    public boolean getUserByUsername(String storedUsername, String storedPassword) {
        SQLiteDatabase LoginDB = this.getReadableDatabase();
        String sql = "select * from " + LoginTable.TABLE + " where COL_USERNAME = ?";
        Cursor cursor = LoginDB.rawQuery(sql, new String[]{LoginTable.COL_USERNAME});
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String username = cursor.getString(1);
                String password = cursor.getString(2);
                if(username == storedUsername && storedPassword == password){
                    return true;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }
}

