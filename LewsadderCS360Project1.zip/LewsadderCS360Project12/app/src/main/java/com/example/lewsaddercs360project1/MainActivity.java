package com.example.lewsaddercs360project1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.R.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;



public class MainActivity extends AppCompatActivity {
    private LoginDatabase LoginDB;
    private static final String TAG = "MYActivity";
    public Button registerButton;
    public Button submitButton;
    public EditText usernameText;
    public EditText passwordText;
    public int x = 0;
    public int y =0;
    public int z = 0;
    public int xyz = 0;
    public String username;
    public String password;
    private Object Context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerButton = (Button) findViewById(R.id.registerButton);
        submitButton = (Button) findViewById(R.id.submitButton);
        registerButton.setEnabled(false);//sets disabled by default
        submitButton.setEnabled(false);//sets disabled by default
        usernameText = (EditText) findViewById(R.id.editTextUsername);//find view of EditText
        passwordText = (EditText) findViewById(R.id.editTextPassword);//find view of EditText


        usernameText.addTextChangedListener(new TextWatcher() {//textWatcher for nameText
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //before text is changed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {//after text has changed
                if (s.toString().length() < 1){ // if text length is less than 1 char
                    submitButton.setEnabled(false); // disable button
                    registerButton.setEnabled(false); // disable button
                    if(y > 0){
                        y -=1;
                    }
                } else {
                    username = usernameText.getText().toString();
                    if(y < 2) {
                        y += 1;
                    }
                    if(y >= 2 && z >= 2) {
                        submitButton.setEnabled(true); // disable button
                        registerButton.setEnabled(true); // disable button
                    }
                }
            }
        });

    passwordText.addTextChangedListener(new TextWatcher() {//textWatcher for nameText
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            //before text is changed
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //while text is changing
        }

        @Override
        public void afterTextChanged(Editable s) {//after text has changed
            if (s.toString().length() < 1){ // if text length is less than 1 char
                submitButton.setEnabled(false); // disable button
                registerButton.setEnabled(false); // disable button
                if(z > 0){
                    z -=1;
                }
            } else {
                password = passwordText.getText().toString();
                if(z < 2) {
                    z += 1;
                }
                if(y >= 2 && z >= 2) {
                    submitButton.setEnabled(true); // disable button
                    registerButton.setEnabled(true); // disable button
                }
            }
        }
    });


        Button next = (Button) findViewById(R.id.registerButton);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    LoginDatabase.getInstance(getApplicationContext());
                    ((LoginDatabase) LoginDB).addUser("user","password");
                    Toast.makeText(MainActivity.this,
                            "User Successfully Registered.", Toast.LENGTH_SHORT).show();
                }catch(Exception E){
                    Toast.makeText(MainActivity.this,
                            "User Failed to Register. \nGuest Access Granted.", Toast.LENGTH_SHORT).show();
                }
                Intent myIntent = new Intent(view.getContext(), activity_pageTwo.class);
                startActivityForResult(myIntent, 0);
            }

        });
        Button next2 = (Button) findViewById(R.id.submitButton);
        next2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    Log.d(TAG,"The database is trying to create");
                        Toast.makeText(MainActivity.this,
                                "User Successfully Logged in.", Toast.LENGTH_SHORT).show();
                }catch(Exception E){
                    Toast.makeText(MainActivity.this,
                            "User Failed to Log in. \nGuest Access Granted.", Toast.LENGTH_SHORT).show();
                }
                Intent myIntent = new Intent(view.getContext(), activity_pageTwo.class);
                startActivityForResult(myIntent, 0);
            }

        });
    }


    public void registerButton(View view) {
    }

    public void submitButton(View view) {
    }
}

