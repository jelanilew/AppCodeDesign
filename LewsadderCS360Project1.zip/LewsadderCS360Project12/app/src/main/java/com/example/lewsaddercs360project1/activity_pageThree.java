package com.example.lewsaddercs360project1;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class activity_pageThree extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    private static final int SEND_SMS_CODE = 23;
    Button sendBtn;
    String phoneNo;
    String message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_three);
        requestSmsSendPermission();
            Button next = (Button) findViewById(R.id.agreeButton);
            next.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    sendSms();
                    Intent myIntent = new Intent(view.getContext(), activity_pageTwo.class);
                    startActivityForResult(myIntent, 0);
                }

            });

            Button next2 = (Button) findViewById(R.id.declineButton);
            next2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Intent myIntent = new Intent(view.getContext(), activity_pageTwo.class);
                    startActivityForResult(myIntent, 0);
                }

            });

    }


    private void sendSms(){
        SmsManager sms = SmsManager.getDefault();
        ArrayList<String> parts = sms.divideMessage("Thank You For Accepting!");
        sms.sendMultipartTextMessage("+15555215554", null, parts, null,
                null);
        Toast.makeText(activity_pageThree.this,
                "SMS Sent to +15555215554", Toast.LENGTH_SHORT).show();}


    private void requestSmsSendPermission() {
        ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.SEND_SMS },
                SEND_SMS_CODE);
    }



}
