package com.example.lewsaddercs360project1;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;

public class activity_pageTwo extends AppCompatActivity {
    public int x = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_two);

        if(x==0) {
            x=1;
            Button next = (Button) findViewById(R.id.nextButton);
            next.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Intent myIntent = new Intent(view.getContext(), activity_pageThree.class);
                    startActivityForResult(myIntent, 0);
                }

            });
        }
    }
    public void nextButton(View view) {
    }
}